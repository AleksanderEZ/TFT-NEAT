using System;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private Vector3 initialPosition;
    private PlayerMovement playerMovement;
    private Genome genome;
    private float distance;
    private bool running = false;
    private NEATPainter painter = new NEATPainter();
    private bool painterEnabled = false;
    private bool won = false;

    private void Awake()
    {
        initialPosition = transform.position;
    }

    private void Start()
    {
        playerMovement = GetComponent<PlayerMovement>();
    }

    public float GetFitness()
    {
        float fitness = -distance + 13;
        fitness = Mathf.Clamp(fitness, 0, 13);
        if (won) fitness += 10;
        return fitness;
    }

    public void SetGenome(Genome genome)
    {
        this.genome = genome;
    }

    public bool IsRunning()
    {
        return running;
    }

    public void StartRunning()
    {
        running = true;
    }

    public void Reset()
    {
        distance = 0;
        genome = null;
        running = false;
        playerMovement.Reset(initialPosition);
    }

    private void Update()
    {
        distance = Vector2.Distance(transform.localPosition, NEAT.Instance.GetGoal().transform.localPosition);
        if (genome != null) genome.SetFitness(GetFitness());
        if (!playerMovement.enabled) running = false;
        if (playerMovement.HasWon()) won = true;
    }

    private void FixedUpdate()
    {
        if (!running) return;
        float[] inputs = GetInputs();
        int[] outputs = Evaluate(inputs);
        playerMovement.SetUp(outputs[0]);
        playerMovement.SetLeft(outputs[1]);
        playerMovement.SetDown(outputs[2]);
        playerMovement.SetRight(outputs[3]);
        if (painterEnabled) painter.PaintGenome(genome);
    }

    private float[] GetInputs()
    {
        float[] inputs = new float[NEAT.INPUTS];
        inputs[0] = distance;
        inputs[1] = transform.localPosition.x;
        inputs[2] = transform.localPosition.y;
        inputs[3] = DistanceToWall(Vector2.up);
        inputs[4] = DistanceToWall(Vector2.left);
        inputs[5] = DistanceToWall(Vector2.right);
        inputs[6] = DistanceToWall(Vector2.down);
        return inputs;
    }

    private float GetDistanceToClosestWall()
    {
        float distance = DistanceToWall(Vector2.up);
        distance = Math.Min(DistanceToWall(Vector2.left), distance);
        distance = Math.Min(DistanceToWall(Vector2.down), distance);
        distance = Math.Min(DistanceToWall(Vector2.right), distance);
        return distance;
    }

    private float DistanceToWall(Vector2 direction)
    {
        RaycastHit[] hits = Physics.RaycastAll(transform.localPosition, direction, 20f, 1 << LayerMask.NameToLayer("Wall"));
        float distance = float.MaxValue;
        if (hits.Length != 0)
        {
            distance = hits[0].distance;
        }
        return distance;
    }

    private int[] Evaluate(float[] inputs)
    {
        return genome.EvaluateNetwork(inputs);
    }
}

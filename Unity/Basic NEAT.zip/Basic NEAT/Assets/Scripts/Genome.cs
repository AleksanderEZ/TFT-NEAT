using System;
using System.Collections.Generic;
using System.Linq;

public class Genome: IComparable<Genome>
{
    private SortedSet<NodeGene> nodes = new SortedSet<NodeGene>();
    private SortedSet<ConnectionGene> connections = new SortedSet<ConnectionGene>();
    private float fitness = 0;
    private Species species;

    public Genome(int inputs, int outputs)
    {
        for (int i = 0; i < inputs; i++)
        {
            NodeGene node = new NodeGene(i);
            node.SetX(NEAT.INPUTS_X);
            node.SetY(i * 2);
            AddNode(node);
        }

        for (int i = 0; i < outputs; i++)
        {
            NodeGene node = new NodeGene(NEAT.INPUTS + i);
            node.SetX(NEAT.OUTPUTS_X);
            node.SetY(i * 2);
            AddNode(node);
        }
    }

    public Genome()
    {

    }

    public static float Distance(Genome genome1, Genome genome2)
    {
        int highest_innovation_gene1 = 0;
        if (genome1.GetConnections().Count > 0) highest_innovation_gene1 = genome1.GetConnections().Max.GetInnovationNumber();
        int highest_innovation_gene2 = 0;
        if (genome2.GetConnections().Count > 0) highest_innovation_gene2 = genome2.GetConnections().Max.GetInnovationNumber();

        if (highest_innovation_gene1 < highest_innovation_gene2)
        {
            Genome temp = genome1;
            genome1 = genome2;
            genome2 = temp;
        }

        int index_genome1 = 0;
        int index_genome2 = 0;

        int disjoint_genes = 0;
        int excess_genes = 0;
        int matching_genes = 0;
        float weight_difference = 0;

        while (index_genome1 < genome1.GetConnections().Count && index_genome2 < genome2.GetConnections().Count)
        {

            ConnectionGene gene1 = genome1.GetConnections().ElementAt(index_genome1);
            ConnectionGene gene2 = genome2.GetConnections().ElementAt(index_genome2);

            int innovation_number1 = gene1.GetInnovationNumber();
            int innovation_number2 = gene2.GetInnovationNumber();

            if (innovation_number1 == innovation_number2)
            {
                matching_genes++;
                weight_difference += Math.Abs(gene1.GetWeight() - gene2.GetWeight());
                index_genome1++;
                index_genome2++;
            }
            else if (innovation_number1 > innovation_number2)
            {
                disjoint_genes++;
                index_genome2++;
            }
            else
            {
                disjoint_genes++;
                index_genome1++;
            }
        }

        weight_difference /= Math.Max(1, matching_genes);
        excess_genes = genome1.GetConnections().Count - index_genome1;

        int maxGenomeSize = Math.Max(genome1.GetConnections().Count, genome2.GetConnections().Count);
        if (maxGenomeSize < 20)
        {
            maxGenomeSize = 1;
        }

        return NEAT.EXCESS_COEFFICIENT * disjoint_genes / maxGenomeSize + NEAT.DISJOINT_COEFFICIENT * excess_genes / maxGenomeSize + NEAT.WEIGHT_COEFFICIENT * weight_difference;
    }

    public static Genome Crossover(Genome parent1, Genome parent2)
    {
        if (parent1.GetFitness() < parent2.GetFitness())
        {
            Genome temp = parent1;
            parent1 = parent2; 
            parent2 = temp;
        }

        Genome child = new Genome(NEAT.INPUTS, NEAT.OUTPUTS);

        int index_parent1 = 0;
        int index_parent2 = 0;

        while (index_parent1 < parent1.GetConnections().Count && index_parent2 < parent2.GetConnections().Count)
        {
            ConnectionGene connection1 = parent1.GetConnections().ElementAt(index_parent1);
            ConnectionGene connection2 = parent2.GetConnections().ElementAt(index_parent2);

            int innovation_number1 = connection1.GetInnovationNumber();
            int innovation_number2 = connection2.GetInnovationNumber();

            if (innovation_number1 == innovation_number2)
            {
                if (UnityEngine.Random.value > 0.5)
                {
                    child.AddConnection(connection1.Copy());
                }
                else
                {
                    child.AddConnection(connection2.Copy());
                }
                index_parent1++;
                index_parent2++;
            }
            else if (innovation_number1 > innovation_number2)
            {
                index_parent2++;
            }
            else
            {
                child.AddConnection(connection1.Copy());
                index_parent1++;
            }
        }

        while (index_parent1 < parent1.GetConnections().Count)
        {
            ConnectionGene connection1 = parent1.GetConnections().ElementAt(index_parent1);
            child.AddConnection(connection1.Copy());
            index_parent1++;
        }

        foreach (ConnectionGene connection in child.GetConnections())
        {
            child.AddNode(connection.GetFrom());
            child.AddNode(connection.GetTo());
        }

        return child;
    }

    public float GetFitness()
    {
        return fitness;
    }

    public void SetFitness(float fitness)
    {
        this.fitness = fitness;
    }

    public SortedSet<NodeGene> GetNodes()
    {
        return nodes;
    }
    public SortedSet<ConnectionGene> GetConnections()
    {
        return connections;
    }

    public void AddNode(NodeGene nodeGene)
    {
        nodes.Add(nodeGene);
    }

    public bool AddConnection(ConnectionGene connectionGene)
    { 
        return connections.Add(connectionGene);
    }

    public void ToggleRandomConnection()
    {
        ConnectionGene[] connectionsArray = connections.ToArray();
        if (connectionsArray.Length == 0) return;
        ConnectionGene connection = connectionsArray[UnityEngine.Random.Range(0, connectionsArray.Length)];
        connection.SetEnabled(!connection.IsEnabled());
    }

    public void MutateNode()
    {
        ConnectionGene[] connectionsArray = connections.ToArray();
        if (connectionsArray.Length == 0) return;
        ConnectionGene connection = connectionsArray[UnityEngine.Random.Range(0, connectionsArray.Length)];
        if (connection == null) return;

        NodeGene from = connection.GetFrom();
        NodeGene to = connection.GetTo();

        NodeGene middle = new NodeGene();
        middle.SetX((from.GetX() + to.GetX()) / 2);
        middle.SetY((from.GetY() + to.GetY()) / 2);

        ConnectionGene connection1 = new ConnectionGene(from, middle);
        ConnectionGene connection2 = new ConnectionGene(middle, to);

        connection1.SetWeight(1);
        connection2.SetWeight(connection.GetWeight());
        connection2.SetEnabled(connection.IsEnabled());
        connections.Remove(connection);

        nodes.Add(middle);
        connections.Add(connection1);
        connections.Add(connection2);
    }

    public void MutateWeightRandom()
    {
        ConnectionGene[] connectionsArray = connections.ToArray();
        if (connectionsArray.Length == 0) return;
        ConnectionGene connection = connectionsArray[UnityEngine.Random.Range(0, connectionsArray.Length)];
        connection.SetWeight(UnityEngine.Random.Range(-2f, 2f));
    }

    public void MutateConnection()
    {
        NodeGene[] nodesArray = nodes.ToArray();
        if (nodesArray.Length <= 0) return;

        for (int i = 0; i < 50; i++)
        {
            NodeGene node1 = nodesArray[UnityEngine.Random.Range(0, nodesArray.Length)];
            NodeGene node2 = nodesArray[UnityEngine.Random.Range(0, nodesArray.Length)];

            if (node1.GetInnovationNumber() == node2.GetInnovationNumber()) continue;
            if (node1.GetX() == node2.GetX()) continue;

            ConnectionGene newConnection;

            if (node1.GetX() < node2.GetX())
            {
                newConnection = new ConnectionGene(node1, node2);
            }
            else
            {
                newConnection = new ConnectionGene(node2, node1);
            }
            newConnection.SetWeight(UnityEngine.Random.Range(-2, 2));

            if (AddConnection(newConnection)) break;
            continue;
        }
    }

    public void MutateWeightShift()
    {
        ConnectionGene[] connectionsArray = connections.ToArray();
        if (connectionsArray.Length == 0) return;
        ConnectionGene connection = connectionsArray[UnityEngine.Random.Range(0, connectionsArray.Length)];
        connection.SetWeight(connection.GetWeight() * UnityEngine.Random.Range(0.75f, 1.251f));
    }

    public int[] EvaluateNetwork(float[] inputs)
    {
        List<NodeGene> input_nodes = new List<NodeGene>();
        List<NodeGene> hidden_nodes = new List<NodeGene>();
        List<NodeGene> output_nodes = new List<NodeGene>();

        foreach (NodeGene node in nodes)
        {
            if (node.GetX() <= NEAT.INPUTS_X)
            {
                input_nodes.Add(node);
            } else if (node.GetX() >= NEAT.OUTPUTS_X) {
                output_nodes.Add(node);
            } else
            {
                hidden_nodes.Add(node);
            }
        }

        if (inputs.Length != input_nodes.Count) return null;

        int[] outputs = new int[NEAT.OUTPUTS];

        if (outputs.Length != output_nodes.Count) return null;

        Queue<NodeGene> input_nodes2 = new Queue<NodeGene>(input_nodes.OrderByDescending(x => x.GetY()));
        int i = 0;
        while (input_nodes2.Count > 0)
        {
            NodeGene node = input_nodes2.Dequeue();
            node.SetOutput(inputs[i]);
            i++;
        }

        Queue<NodeGene> hidden_nodes2 = new Queue<NodeGene>(hidden_nodes.OrderBy(x => x.GetX()));

        while (hidden_nodes2.Count > 0)
        {
            NodeGene node = hidden_nodes2.Dequeue();
            node.CalculateOutput();
        }

        Queue<NodeGene> output_nodes2 = new Queue<NodeGene>(output_nodes.OrderByDescending(x => x.GetY()));
        i = 0;
        while (output_nodes2.Count > 0)
        {
            NodeGene node = output_nodes2.Dequeue();
            node.CalculateOutput();
            outputs[i] = (int)Math.Round(node.GetOutput());
            i++;
        }
        return outputs;
    }

    public void SetSpecies(Species species)
    {
        this.species = species;
    }

    public Species GetSpecies() {
        return this.species; 
    }

    public int CompareTo(Genome other)
    {
        if (this == other) return 0;
        if (other == null) return -1;
        if (this.GetFitness() < other.GetFitness()) return -1;
        if (this.GetFitness() == other.GetFitness()) return 0;
        return 1;
    }
}

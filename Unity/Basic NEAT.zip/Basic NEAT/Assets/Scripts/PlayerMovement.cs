using System.Threading;
using TMPro;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    private class Control
    {
        public int up;
        public int left;
        public int down;
        public int right;
        public Control()
        {
            up = 0;
            left = 0;
            down = 0;
            right = 0;
        }
    }

    [SerializeField]
    private float speed;
    private Control control = new Control();
    private CharacterController characterController;
    private float timer = 0;
    private const int timeout = 3;
    private Vector3 lastPosition;
    private bool won = false;

    public void SetUp(int up)
    {
        control.up = up;
    }

    public void SetLeft(int left)
    {
        control.left = left;
    }

    public void SetDown(int down)
    {
        control.down = down;
    }

    public void SetRight(int right)
    {
        control.right = right;
    }

    private void Start()
    {
        characterController = GetComponent<CharacterController>();
    }

    private void FixedUpdate()
    {
        Vector3 direction = new Vector3(control.right - control.left, control.up - control.down, 0);
        lastPosition = transform.localPosition;
        characterController.Move(direction * Time.deltaTime * speed);
        if (Moved())
        {
            timer = 0;
        }
        else
        {
            timer += Time.deltaTime;
        }
        if (timer > timeout)
        {
            Deactivate();
        }
        var angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.AngleAxis(angle - 90, Vector3.forward);
    }

    private bool Moved()
    {
        if (System.Math.Abs(transform.localPosition.x - lastPosition.x) < Time.deltaTime * speed && System.Math.Abs(transform.localPosition.y - lastPosition.y) < Time.deltaTime * speed)
        {
            return false;
        }
        return true;
    }

    private void OnControllerColliderHit(ControllerColliderHit hit)
    {
        if (IsWall(hit.collider))
        {
            Deactivate();
        }

        if (IsGoal(hit.collider))
        {
            Deactivate(goal: true);
        }
    }

    private bool IsWall(Collider collision)
    {
        if (collision.gameObject.layer == LayerMask.NameToLayer("Wall"))
        {
            return true;
        }
        return false;
    }

    private bool IsGoal(Collider collision)
    {
        if (collision.gameObject.layer == LayerMask.NameToLayer("Goal"))
        {
            return true;
        }
        return false;
    }

    private void Deactivate(bool goal = false)
    {
        enabled = false;
        GetComponent<SpriteRenderer>().color = Color.gray;
        if (goal)
        {
            won = true;
        }
    }

    public void Reset(Vector3 initialPosition)
    {
        characterController.enabled = false;
        transform.localPosition = initialPosition;
        lastPosition = initialPosition;
        control = new Control();
        transform.rotation = Quaternion.identity;
        enabled = true;
        GetComponent<SpriteRenderer>().color = Color.white;
        timer = 0;
        characterController.enabled = true;
    }

    public bool HasWon()
    {
        return won;
    }
}

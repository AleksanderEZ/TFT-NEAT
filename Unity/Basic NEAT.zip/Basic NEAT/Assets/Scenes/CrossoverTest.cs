using System;
using UnityEngine;

public class CrossoverTest : MonoBehaviour
{
    Genome parent1;
    Genome parent2;
    Genome child;
    NEATPainter painter = new NEATPainter();

    private const float MUTATE_CONNECTION_CHANCE = 0.5f;
    private const float MUTATE_NODE_CHANCE = 0.2f;
    private const float MUTATE_CONNECTION_WEIGHT_SHIFT_CHANCE = 0.2f;
    private const float MUTATE_CONNECTION_WEIGHT_RANDOM_CHANCE = 0.3f;
    private const float MUTATE_CONNECTION_TOGGLE_CHANCE = 0.2f;
    GenomeMutator mutator = new GenomeMutator(MUTATE_CONNECTION_CHANCE, MUTATE_NODE_CHANCE, MUTATE_CONNECTION_WEIGHT_SHIFT_CHANCE, MUTATE_CONNECTION_WEIGHT_RANDOM_CHANCE, MUTATE_CONNECTION_TOGGLE_CHANCE);

    void Start()
    {
        //PaperExample();
        MyExample();
        child = Genome.Crossover(parent1, parent2);
    }

    private void MyExample()
    {
        parent1 = new Genome(NEAT.INPUTS, NEAT.OUTPUTS);
        parent2 = new Genome(NEAT.INPUTS, NEAT.OUTPUTS);
        for (int i = 0; i < 10; i++) {
            mutator.Mutate(parent1);
            mutator.Mutate(parent2);
        }
        child = Genome.Crossover(parent1, parent2);
    }

    private void PaperExample()
    {
        parent1 = new Genome();
        parent2 = new Genome();

        NodeGene nodeGene0 = new NodeGene();
        ConnectionGene connection0 = new ConnectionGene();

        NodeGene nodeGene1 = new NodeGene();
        nodeGene1.SetY(10);
        nodeGene1.SetX(0);
        NodeGene nodeGene2 = new NodeGene();
        nodeGene2.SetY(5);
        nodeGene2.SetX(0);
        NodeGene nodeGene3 = new NodeGene();
        nodeGene3.SetY(0);
        nodeGene3.SetX(0);
        NodeGene nodeGene4 = new NodeGene();
        nodeGene4.SetX(30);
        nodeGene4.SetY(5);
        NodeGene nodeGene5 = new NodeGene();
        nodeGene5.SetX(15);
        nodeGene5.SetY(5);
        NodeGene nodeGene6 = new NodeGene();
        nodeGene6.SetX(20);
        nodeGene6.SetY(5);
        NodeGene nodeGene52 = new NodeGene();
        nodeGene52.SetX(10f);
        nodeGene52.SetY(2.5f);
        nodeGene52.SetInnovationNumber(nodeGene5.GetInnovationNumber());

        ConnectionGene connectionGene14 = new ConnectionGene(nodeGene1, nodeGene4);
        ConnectionGene connectionGene24 = new ConnectionGene(nodeGene2, nodeGene4);
        connectionGene24.SetEnabled(false);
        ConnectionGene connectionGene34 = new ConnectionGene(nodeGene3, nodeGene4);
        ConnectionGene connectionGene25 = new ConnectionGene(nodeGene2, nodeGene5);
        ConnectionGene connectionGene54 = new ConnectionGene(nodeGene5, nodeGene4);
        ConnectionGene connectionGene56 = new ConnectionGene(nodeGene52, nodeGene6);
        ConnectionGene connectionGene64 = new ConnectionGene(nodeGene6, nodeGene4);
        ConnectionGene connectionGene15 = new ConnectionGene(nodeGene1, nodeGene5);
        ConnectionGene connectionGene35 = new ConnectionGene(nodeGene3, nodeGene52);
        ConnectionGene connectionGene16 = new ConnectionGene(nodeGene1, nodeGene6);
        ConnectionGene connectionGene54dis = new ConnectionGene(nodeGene5, nodeGene4);
        connectionGene54dis.SetEnabled(false);
        connectionGene54dis.SetInnovationNumber(connectionGene54.GetInnovationNumber());
        ConnectionGene connectionGene252 = new ConnectionGene(nodeGene2, nodeGene52);
        connectionGene252.SetInnovationNumber(connectionGene25.GetInnovationNumber());


        parent1.AddNode(nodeGene1);
        parent1.AddNode(nodeGene2);
        parent1.AddNode(nodeGene3);
        parent1.AddNode(nodeGene4);
        parent1.AddNode(nodeGene5);
        parent1.AddConnection(connectionGene14);
        parent1.AddConnection(connectionGene24);
        parent1.AddConnection(connectionGene34);
        parent1.AddConnection(connectionGene25);
        parent1.AddConnection(connectionGene54);
        parent1.AddConnection(connectionGene15);

        parent2.AddNode(nodeGene1);
        parent2.AddNode(nodeGene2);
        parent2.AddNode(nodeGene3);
        parent2.AddNode(nodeGene4);
        parent2.AddNode(nodeGene52);
        parent2.AddNode(nodeGene6);
        parent2.AddConnection(connectionGene14);
        parent2.AddConnection(connectionGene24);
        parent2.AddConnection(connectionGene34);
        parent2.AddConnection(connectionGene252);
        parent2.AddConnection(connectionGene54dis);
        parent2.AddConnection(connectionGene56);
        parent2.AddConnection(connectionGene64);
        parent2.AddConnection(connectionGene35);
        parent2.AddConnection(connectionGene16);

        parent1.SetFitness(2);
        parent2.SetFitness(2);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown("4"))
        {
            painter.Clear();
            painter.AddGenomeFull(parent1);
            painter.AddGenomeFull(parent2);
            painter.AddGenomeFull(child);
        }
        if (Input.GetKeyDown("1"))
        {
            painter.PaintGenome(parent1);
        }
        if (Input.GetKeyDown("2"))
        {
            painter.PaintGenome(parent2);
        }
        if (Input.GetKeyDown("3"))
        {
            painter.PaintGenome(child);
        }
    }
}

using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class PlayerController_legacy : MonoBehaviour
{
    private Rigidbody2D rb;
    private Vector2 direction;
    [SerializeField] private float speed;
    [SerializeField] private float jumpForce;
    [SerializeField] private Transform groundCheck;
    [SerializeField] private LayerMask whatIsGround;
    [SerializeField] private ContactFilter2D whatIsLadder;
    [SerializeField] private ContactFilter2D whatIsLadderTop;
    [SerializeField] private LayerMask whatIsBarrel;
    private bool facingRight = true;
    private Animator animator;
    private bool dying;
    private Collider2D[] results = new Collider2D[1];
    private bool canClimb;
    private bool climbing;
    private bool climbingAndMoving;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
    }

    private void Update()
    {
        SendDataToAnimator();
        if (climbing)
        {
            Climbing();
            return;
        }
        if (Input.GetAxisRaw("Vertical") != 0 && canClimb)
        {
            climbing = true;
        }
        if (Input.GetButtonDown("Jump") && isGrounded())
        {
            direction = Vector2.up * jumpForce;
        }
        else
        {
            direction += Physics2D.gravity * Time.deltaTime;
        }
        if (isGrounded())
        {
            direction.x = Input.GetAxisRaw("Horizontal");
            direction.y = Mathf.Max(direction.y, -1);
        }
        Flip();
    }

    private void Climbing()
    {
        direction.x = 0;
        direction.y = Input.GetAxisRaw("Vertical") * 0.5f;
        if (direction.y != 0)
        {
            climbingAndMoving = true;
        } else
        {
            climbingAndMoving = false;
        }
        if (isLadderTop())
        {
            direction.y = Mathf.Min(direction.y, 0f);
        }
        if (isGroundedClimbing()) {
            climbing = false;
        }
    }

    private bool isLadderTop()
    {
        results[0] = null;
        rb.OverlapCollider(whatIsLadderTop, results);
        return results[0] != null;
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.layer == 11)
        {
            Debug.Log("Collision");
            animator.Play("Player_dying");
        }
    }

    public void Revive()
    {
        dying = false;
    }

    private void SendDataToAnimator()
    {
        animator.SetFloat("Speed", Mathf.Abs(direction.x));
        animator.SetBool("Dying", dying);
        animator.SetBool("Climbing", climbing);
        animator.SetBool("ClimbingAndMoving", climbingAndMoving);
    }

    private void Flip()
    {
        if (direction.x > 0 && !facingRight || direction.x < 0 && facingRight)
        {
            facingRight = !facingRight;
            Vector3 localScale = transform.localScale;
            localScale.x *= -1f;
            transform.localScale = localScale;
        }
    }

    private bool isGrounded()
    {
        return Physics2D.OverlapCircle(groundCheck.position, 0.2f, whatIsGround);
    }

    private bool isGroundedClimbing()
    {
        return Physics2D.Raycast(groundCheck.position, Vector2.down, 0.1f, whatIsGround);
    }

    private void FixedUpdate()
    {
        if (animator.GetCurrentAnimatorStateInfo(0).IsName("Player_finished_climbing")) return;
        rb.MovePosition(rb.position + direction * speed * Time.deltaTime);
        results[0] = null;
        rb.OverlapCollider(whatIsLadder, results);
        if (results[0] != null)
        {
            canClimb = true;
        } else
        {
            canClimb = false;
        }
    }
}

using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private Genome genome;
    private bool playerEnabled = false;
    private PlayerMovement playerMovement;
    private Vector3 initialPosition;
    private bool won = false;
    private float distance;

    private void Start()
    {
        playerMovement = GetComponent<PlayerMovement>();
        initialPosition = transform.position;
    }
    
    public void SetGenome(Genome genome)
    {
        this.genome = genome;
    }

    public void StartRunning()
    {
        playerEnabled = true;
    }

    public bool IsRunning()
    {
        return playerEnabled;
    }

    private float GetFitness()
    {
        float fitness = -distance + 13;
        fitness = Mathf.Clamp(fitness, 0, 13);
        if (won) fitness += 10;
        return fitness;
    }

    public void Reset()
    {
        distance = 0;
        genome = null;
        playerEnabled = false;
        playerMovement.Reset(initialPosition);
    }

    private void Update()
    {
        distance = Vector2.Distance(transform.localPosition, NEAT.Instance.GetGoal().transform.localPosition);
        if (genome != null) genome.SetFitness(GetFitness());
        if (!playerMovement.enabled) playerEnabled = false;
        if (playerMovement.HasWon()) won = true;
    }

    private void FixedUpdate()
    {
        if (!playerEnabled) return;
        Vector2 paulinePos = GameManager.Instance.GetPaulinePosition();
        // distance = Mathf.Sqrt(Mathf.Pow(paulinePos.x - transform.position.x, 2f) + Mathf.Pow((paulinePos.y - transform.position.y), 2f));
        distance = paulinePos.y - transform.localPosition.y;
        float[] inputs = GetInputs();
        float[] outputs = Evaluate(inputs);
        playerMovement.SetControls(outputs);
    }

    private float[] GetInputs()
    {
        float[] inputs = new float[NEAT.INPUTS];
        float playerGrounded = GetPlayerGrounded();
        float playerClimbing = GetPlayerClimbing();
        float playerColidingWithLadder = GetPlayerCollidingWithLadder();
        Vector2[] relativePosLadders = GetRelativePositionsOfLadders();
        Vector2 relativePosClosestBarrels = GetRelativePositionsOfClosestBarrels();
        Vector2 velocitiesOfClosestBarrels = GetVelocitiesOfClosestBarrels();
        inputs[0] = transform.localPosition.x;
        inputs[1] = transform.localPosition.y;
        inputs[2] = playerGrounded;
        inputs[3] = playerClimbing;
        inputs[4] = playerColidingWithLadder;
        int j = 5;
        for (int i = 0; i < relativePosLadders.Length; i++)
        {
            inputs[j] = relativePosLadders[i].x;
            inputs[j + 1] = relativePosLadders[i].y;
            j += 2;
        }
        inputs[j + 1] = relativePosClosestBarrels.x;
        inputs[j + 2] = relativePosClosestBarrels.y;
        inputs[j + 3] = velocitiesOfClosestBarrels.x;
        inputs[j + 4] = velocitiesOfClosestBarrels.y;
        return inputs;
    }

    private float[] Evaluate(float[] inputs)
    {
        return genome.EvaluateNetwork(inputs);
    }

    private Vector2 GetVelocitiesOfClosestBarrels()
    {
        return GameManager.Instance.GetVelocitiesOfClosestBarrels(gameObject);
    }

    private Vector2 GetRelativePositionsOfClosestBarrels()
    {
        return GameManager.Instance.GetRelativePositionsOfClosestBarrels(gameObject);
    }

    private Vector2[] GetRelativePositionsOfLadders()
    {
        return GameManager.Instance.GetRelativePositionsOfLadders(gameObject);
    }

    private float GetPlayerCollidingWithLadder()
    {
        float returnValue = playerMovement.CanClimb() ? 1 : 0;
        return returnValue;
    }

    private float GetPlayerClimbing()
    {
        float returnValue = playerMovement.IsClimbing() ? 1 : 0;
        return returnValue;
    }

    private float GetPlayerGrounded()
    {
        float returnValue = playerMovement.IsGrounded() ? 1 : 0;
        return returnValue;
    }
}

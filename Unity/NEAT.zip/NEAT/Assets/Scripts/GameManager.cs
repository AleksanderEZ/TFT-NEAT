using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using static UnityEditor.Experimental.GraphView.GraphView;

public class GameManager : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI generationText;
    [SerializeField] private TextMeshProUGUI generationBestFitnessText;
    [SerializeField] private TextMeshProUGUI populationText;
    [SerializeField] private TextMeshProUGUI populationAliveText;
    [SerializeField] private TextMeshProUGUI totalBestFitnessText;
    [SerializeField] private GameObject playerPrefab;
    [SerializeField] private Transform pauline;
    private GameObject[] ladders;

    public static GameManager Instance { get; private set; }
    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(this);
        }
        else
        {
            Instance = this;
        }
    }

    private void Start()
    {
        GatherLadders();
    }

    private void GatherLadders()
    {
        ladders = GameObject.FindGameObjectsWithTag("Ladder");
        GameObject[] laddersAux = new GameObject[ladders.Length];
        int j = 0;
        for (int i = 0; i < laddersAux.Length; i++) {
            if (ladders[i].name.StartsWith("Ladder"))
            {
                laddersAux[i] = ladders[i];
                j++;
            }
        };
        ladders = new GameObject[j];
        j = 0;
        for (int i = 0; i < laddersAux.Length; i++)
        {
            if (laddersAux[i] != null)
            {
                ladders[j] = laddersAux[i];
                j++;
            }
        }
    }

    public Vector2 GetPaulinePosition()
    {
        return new Vector2(pauline.position.x, pauline.position.y);
    }

    public Vector2[] GetRelativePositionsOfLadders(GameObject player)
    {
        int i = 0;
        Vector2[] relativePositions = new Vector2[ladders.Length];
        foreach (GameObject ladder in ladders)
        {
            Vector2 ladderRel = new Vector2(player.transform.position.x - ladder.transform.position.x, player.transform.position.y - ladder.transform.position.y);
            relativePositions[i] = ladderRel;
            i++;
        }
        return relativePositions;
    }

    public Vector2 GetRelativePositionsOfClosestBarrels(GameObject player)
    {
        GameObject closestBarrels = GetClosestBarrels(player);
        if (closestBarrels == null) return new Vector2(float.MaxValue, float.MaxValue);
        return new Vector2(player.transform.position.x - closestBarrels.transform.position.x, player.transform.position.y - closestBarrels.transform.position.y);
    }

    public Vector2 GetVelocitiesOfClosestBarrels(GameObject player)
    {
        GameObject closestBarrels = GetClosestBarrels(player);
        if (closestBarrels == null) return new Vector2(0, 0);
        return closestBarrels.GetComponent<BarrelMovementController>().direction;
    }

    public GameObject GetClosestBarrels(GameObject player)
    {
        GameObject[] barrels = GameObject.FindGameObjectsWithTag("Barrel");
        List<float> barrelDistances = new List<float>();
        for (int i = 0; i < barrels.Length; i++)
        {
            barrelDistances.Add(Vector2.Distance(player.transform.position, barrels[i].transform.position));
        }
        if (barrelDistances.Count <= 0) return null;
        return barrels[barrelDistances.IndexOf(barrelDistances.Min())];
    }
}
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BarrelController : MonoBehaviour
{
    private static List<GameObject> barrels = new List<GameObject>();
    [SerializeField] private Transform down;
    [SerializeField] private Transform right;
    [SerializeField] private GameObject barrel;
    [SerializeField] private Transform player;

    internal void ThrowBarrelDown()
    {
        ThrowBarrel(down.position, -1);
    }

    internal void ThrowBarrelRight()
    {
        ThrowBarrel(right.position);
    }

    private void ThrowBarrel(Vector2 position, int facingRight = 1)
    {
        GameObject instanceOfBarrel = Instantiate(barrel, position, Quaternion.identity);
        barrels.Add(instanceOfBarrel);
        instanceOfBarrel.GetComponent<BarrelMovementController>().facingRight = facingRight;
        instanceOfBarrel.GetComponent<BarrelMovementController>().player = player;
    }

    public static void Reset()
    {
        foreach (GameObject barrel in barrels)
        {
            Destroy(barrel);
        }
        barrels.Clear();
    }
}

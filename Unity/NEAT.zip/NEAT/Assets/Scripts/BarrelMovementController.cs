using System;
using System.Net.NetworkInformation;
using UnityEditor.Tilemaps;
using UnityEngine;
using UnityEngine.UI;

public class BarrelMovementController : MonoBehaviour
{
    [SerializeField] private Transform groundCheck;
    [SerializeField] private LayerMask whatIsFloor;
    [SerializeField] private Transform leftCheck;
    [SerializeField] private Transform rightCheck;
    internal Vector2 direction;
    [SerializeField] private float speed;
    [SerializeField] private float fallingSpeed;
    private Animator animator;
    public int facingRight = 1;
    [SerializeField] private LayerMask whatIsFinishBarrels;
    [SerializeField] private LayerMask whatIsBounce;
    private bool canFall;
    [SerializeField] private LayerMask whatIsLadderForBarrel;
    internal Transform player;

    private void Awake()
    {
        animator = GetComponent<Animator>();
    }

    private void Update()
    {
        canFall = CanFall();
        BarrelOverPlayerAndLadder();
        if (!canFall)
        {
            direction.x = speed * facingRight;
            direction.y = 0;
        } else
        {
            direction.x = 0;
            direction.y = -fallingSpeed;
        }
    }

    private void BarrelOverPlayerAndLadder()
    {
        if (BarrelOverLadder() && BarrelOverPlayer()) {
            transform.Translate(Vector2.down * 0.4f);
            facingRight *= -1;
        }
    }

    private bool BarrelOverPlayer()
    {
        if (Mathf.Abs(player.position.x - transform.position.x) <= 1f)
        {
            return true;
        } else
        {
            return false;
        }
    }

    private bool BarrelOverLadder()
    {
        return Physics2D.Raycast(groundCheck.position, Vector2.down, 0.2f, whatIsLadderForBarrel);
    }

    private bool CanFall()
    {
        return !Physics2D.OverlapCircle(groundCheck.position, 0.1f, whatIsFloor);
    }

    private void FixedUpdate()
    {
        SendDataToAnimator();
        CheckDestroy();
        Bounce();
        transform.Translate(direction * Time.deltaTime);
    }

    private void CheckDestroy()
    {
        if (Physics2D.OverlapCircle(groundCheck.position, 1f, whatIsFinishBarrels))
        {
            Destroy(gameObject);
        }
    }

    private void Bounce()
    {
        if (facingRight == -1)
        {
            if (Physics2D.Raycast(leftCheck.position, Vector2.left, 0.2f, whatIsBounce))
            {
                facingRight *= -1;
            }
        } else
        {
            if (Physics2D.Raycast(rightCheck.position, Vector2.right, 0.2f, whatIsBounce))
            {
                facingRight *= -1;
            }
        }
    }

    private void SendDataToAnimator()
    {
        animator.SetBool("Falling", direction.y < 0 && !Physics2D.Raycast(groundCheck.position, Vector2.down, 0.2f, whatIsFloor));
    }
}

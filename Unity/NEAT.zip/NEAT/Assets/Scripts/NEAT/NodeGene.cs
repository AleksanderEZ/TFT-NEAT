using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NodeGene : IComparable<NodeGene>
{
    private float x, y;
    private float output;
    private List<ConnectionGene> incomingConnections = new List<ConnectionGene>();
    private static int INNOVATION_NUMBER = NEAT.INPUTS + NEAT.OUTPUTS;
    private int innovation_number;

    public NodeGene()
    {
        innovation_number = INNOVATION_NUMBER;
        INNOVATION_NUMBER++;
    }

    public NodeGene(int innovationNumber)
    {
        innovation_number = innovationNumber;
    }

    public float GetX() { return x; }
    public float GetY() { return y; }
    public void SetX(float x) { this.x = x; }
    public void SetY(float y) { this.y = y; }

    public float GetOutput()
    {
        return output;
    }

    internal void SetOutput(float output)
    {
        this.output = output;
    }
    public void AddIncomingConnection(ConnectionGene connection) 
    {
        incomingConnections.Add(connection);
    }

    public void RemoveIncomingConnection(ConnectionGene connection)
    {
        incomingConnections.Remove(connection);
    }

    public void CalculateOutput()
    {
        if (incomingConnections == null && x != 0) { output = 0; return; }
        float sum = 0;
        foreach (ConnectionGene connectionGene in incomingConnections)
        {
            if (connectionGene.IsEnabled())
            {
                sum += connectionGene.GetWeight() * connectionGene.GetFrom().GetOutput();
            }
        }
        output = ActivationFunctions.Sigmoid(sum);
    }

    public int CompareTo(NodeGene other)
    {
        if (this == other) return 0;
        if (other == null) return -1;
        if (GetInnovationNumber() < other.GetInnovationNumber()) return -1;
        if (GetInnovationNumber() == other.GetInnovationNumber()) return 0;
        return 1;
    }

    public int GetInnovationNumber()
    {
        return innovation_number;
    }

    public void SetInnovationNumber(int innovationNumber)
    {
        innovation_number = innovationNumber;
    }

    public NodeGene Copy()
    {
        NodeGene copy = new NodeGene(innovation_number);
        copy.SetX(x);
        copy.SetY(y);
        return copy;
    }
}

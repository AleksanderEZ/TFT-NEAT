using System;

public static class ActivationFunctions
{
    public static float Sigmoid(float x)
    {
        return (float)(1d / (1 + Math.Exp(-x)));
    }
}

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;

public class NEAT : MonoBehaviour
{
    public static NEAT Instance;
    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        } else
        {
            Destroy(this);
        }
        UnityEngine.Random.InitState(DateTime.Now.Millisecond);
    }

    public const int INPUTS = 36;
    public const int OUTPUTS = 5;
    public const float INPUTS_X = 0;
    public const float OUTPUTS_X = 30;
    public const int POPULATION = 100;
    public const float ELITISM = 0.5f;
    public const int STALE_GENERATIONS_LIMIT = 5;
    public const float DISTANCE_THRESHOLD = 4;
    public const float EXCESS_COEFFICIENT = 1;
    public const float DISJOINT_COEFFICIENT = 1;
    public const float WEIGHT_COEFFICIENT = 1;

    private const float MUTATE_CONNECTION_CHANCE = 0.5f;
    private const float MUTATE_NODE_CHANCE = 0.2f;
    private const float MUTATE_CONNECTION_WEIGHT_SHIFT_CHANCE = 0.2f;
    private const float MUTATE_CONNECTION_WEIGHT_RANDOM_CHANCE = 0.3f;
    private const float MUTATE_CONNECTION_TOGGLE_CHANCE = 0.2f;

    [SerializeField]
    private GameObject playerPrefab;
    [SerializeField]
    private GameObject generationsText; 
    [SerializeField]
    private GameObject maxFitnessText; 
    [SerializeField]
    private GameObject avgFitnessText;
    private int STALE_GENERATIONS = 0;
    private int GENERATION = 0;
    private float MAX_FITNESS = 0;
    private float AVG_FITNESS = 0;
    private GenomeMutator mutator;
    private bool running = false;
    private PlayerController[] players = new PlayerController[POPULATION];
    private List<Genome> genomes = new List<Genome>();
    private List<Species> speciesList = new List<Species>();

    private void Start()
    {
        mutator = new GenomeMutator(MUTATE_CONNECTION_CHANCE, MUTATE_NODE_CHANCE, MUTATE_CONNECTION_WEIGHT_SHIFT_CHANCE, MUTATE_CONNECTION_WEIGHT_RANDOM_CHANCE, MUTATE_CONNECTION_TOGGLE_CHANCE);
        InitializePopulation();
    }

    private void InitializePopulation()
    {
        for (int i = 0; i < POPULATION; i++)
        {
            PlayerController player = Instantiate(playerPrefab).GetComponent<PlayerController>();
            Genome genome = new Genome(INPUTS, OUTPUTS);
            mutator.Mutate(genome);
            genomes.Add(genome);
            players[i] = player;
        }
    }

    private void Update()
    {
        if (STALE_GENERATIONS >= STALE_GENERATIONS_LIMIT)
        {
            Debug.LogWarning("Stop condition has been reached");
            enabled = false;
            return;
        }
        if (running) return;
        running = true;
        UI();
        Run();
        StartCoroutine(Evolve());
    }

    private void UI()
    {
        TextMeshProUGUI gens = generationsText.GetComponent<TextMeshProUGUI>();
        TextMeshProUGUI maxFitness = maxFitnessText.GetComponent<TextMeshProUGUI>();
        TextMeshProUGUI avgFitness = avgFitnessText.GetComponent<TextMeshProUGUI>();

        gens.text = "Generation: " + GENERATION.ToString();
        maxFitness.text = "Max fitness: " + MAX_FITNESS.ToString("n2");
        avgFitness.text = "Avg fitness: " + AVG_FITNESS.ToString("n2");
    }

    private void Run()
    {
        for (int i = 0; i < players.Length; i++)
        {
            players[i].SetGenome(genomes[i]);
        }
        for (int i = 0; i < players.Length; i++)
        {
            players[i].StartRunning();
        }
    }

    private IEnumerator Evolve()
    {
        while (PlayersAlive())
        {
            yield return null;
        }

        GetStats();
        ResetSpecies();
        CullSpecies();
        RemoveStaleSpecies();
        BreedChildren();
        MutatePopulation();
        Reset();

        GENERATION++;
        running = false;
    }

    private void GetStats()
    {
        float sum = 0;
        foreach (Species species in speciesList)
        {
            MAX_FITNESS = Math.Max(MAX_FITNESS, species.GetMaxFitness());
            sum += species.GetAvgFitness();
        }
        AVG_FITNESS = sum / speciesList.Count;
        if (speciesList.Count == 0) AVG_FITNESS = 0;
    }

    private void ResetSpecies()
    {
        foreach (Species species in speciesList)
        {
            species.Reset();
        }

        foreach (Genome genome in genomes)
        {
            if (genome.GetSpecies() != null) continue;

            bool found = false;
            foreach (Species species in speciesList)
            {
                if (species.AddGenome(genome))
                {
                    found = true;
                    break;
                }
            }
            if (!found)
            {
                speciesList.Add(new Species(genome));
            }
        }

        foreach (Species species in speciesList)
        {
            species.EvaluateFitness();
        }
    }

    private void CullSpecies()
    {
        foreach (Species species in speciesList)
        {
            species.CullSpecies(ELITISM);
        }
    }

    private void RemoveStaleSpecies()
    {
        for (int i = 0; i < speciesList.Count; i++)
        {
            if (speciesList.ElementAt(i).Count() <= 1)
            {
                speciesList.ElementAt(i).Die();
                speciesList.Remove(speciesList.ElementAt(i));
                i--;
            }
        }
    }

    private void BreedChildren()
    {
        if (speciesList.Count <= 0) return;
        for (int i = 0; i < genomes.Count; i++)
        {
            if (genomes[i].GetSpecies() == null)
            {
                Species species = speciesList.ElementAt(UnityEngine.Random.Range(0, speciesList.Count));
                genomes[i] = species.BreedChild();
                species.AddGenome(genomes[i], force: true);
            }
        }
    }

    private void MutatePopulation()
    {
        foreach (Genome genome in genomes)
        {
            if(genome.GetFitness() < AVG_FITNESS) mutator.Mutate(genome);
        }
    }

    private bool PlayersAlive()
    {
        foreach (PlayerController player in players)
        {
            if (player.IsRunning())
            {
                return true;
            }
        }
        return false;
    }

    private void Reset()
    {
        for (int i = 0; i < players.Length; i++)
        {
            players[i].Reset();
        }
        BarrelController.Reset();
    }

    [SerializeField]
    private GameObject goal;

    public GameObject GetGoal()
    {
        return goal;
    }
}

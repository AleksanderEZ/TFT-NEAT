using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

public class Species
{
    private List<Genome> genomes = new List<Genome>();
    private Genome representative;
    private float avgFitness = 0;
    private float adjustedFitness = 0;

    public Species(Genome representative) { 
        representative.SetSpecies(this);
        this.representative = representative;
        genomes.Add(representative);
    }

    public bool AddGenome(Genome genome, bool force = false)
    {
        float distance = Genome.Distance(representative, genome);
        if (distance < NEAT.DISTANCE_THRESHOLD || force)
        {
            genome.SetSpecies(this);
            genomes.Add(genome);
            return true;
        } else
        {
            return false;
        }
    }

    public void Die()
    {
        foreach (Genome genome in genomes)
        {
            genome.SetSpecies(null);
        }
    }

    public void EvaluateFitness()
    {
        float sum = 0;
        foreach (Genome genome in genomes)
        {
            sum += genome.GetFitness();
        }
        avgFitness = sum / genomes.Count;
    }

    public void Reset()
    {
        CalculateSpeciesAdjustedFitness();
        representative = genomes.ElementAt(UnityEngine.Random.Range(0, genomes.Count));
        Die();
        genomes.Clear();
        genomes.Add(representative);
        representative.SetSpecies(this);
        avgFitness = 0;
    }

    private void CalculateSpeciesAdjustedFitness()
    {
        adjustedFitness = 0;
        foreach (Genome genome in genomes)
        {
            adjustedFitness += GetAdjustedFitness(genome);
        }
    }

    public float GetTotalAdjustedFitness()
    {
        return adjustedFitness;
    }

    public void CullSpecies(float elitism = 0.5f)
    {
        Queue<Genome> orderedGenomes = new Queue<Genome>(genomes.OrderBy(x => x.GetFitness()));

        for (int i = 0; i < genomes.Count - genomes.Count * elitism; i++)
        {
            Genome genome = orderedGenomes.Dequeue();
            genome.SetSpecies(null);
        }
    }

    public Genome BreedChild()
    {
        int randomIndex = UnityEngine.Random.Range(0, genomes.Count);
        Genome parent1 = genomes.ElementAt(randomIndex);

        randomIndex = UnityEngine.Random.Range(0, genomes.Count);
        Genome parent2 = genomes.ElementAt(randomIndex);

        return Genome.Crossover(parent1, parent2);
    }

    public Genome[] BreedChildren(int amount)
    {
        Genome[] children = new Genome[amount]; 
        for (int i = 0; i < amount; i++)
        {
            children[i] = BreedChild();
            children[i].SetSpecies(this);
            genomes.Add(children[i]);
        }
        return children;
    }

    public int Count()
    {
        return genomes.Count;
    }

    public List<Genome> GetGenomes()
    {
        return genomes;
    }

    public Genome GetRepresentative()
    {
        return representative;
    }

    public float GetAvgFitness()
    {
        return avgFitness;
    }

    public float GetMaxFitness()
    {
        float maxFitness = 0;
        foreach (Genome genome in genomes)
        {
            maxFitness = Math.Max(maxFitness, genome.GetFitness());
        }
        return maxFitness;
    }

    public float GetAdjustedFitness(Genome genome)
    {
        int distanceSum = 0;
        foreach (Genome otherGenome in genomes)
        {
            if (genome == otherGenome) continue;
            distanceSum += Sharing(genome, otherGenome);
        }
        return genome.GetFitness() / distanceSum ;
    }

    private int Sharing(Genome genome, Genome otherGenome)
    {
        if (Genome.Distance(genome, otherGenome) > NEAT.DISTANCE_THRESHOLD) return 0;
        return 1;
    } 
}

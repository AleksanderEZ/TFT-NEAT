using UnityEngine;

public class GenomeMutator
{
    private float MUTATE_CONNECTION_CHANCE;
    private float MUTATE_NODE_CHANCE;
    private float MUTATE_CONNECTION_WEIGHT_SHIFT_CHANCE;
    private float MUTATE_CONNECTION_WEIGHT_RANDOM_CHANCE;
    private float MUTATE_CONNECTION_TOGGLE_CHANCE;

    public GenomeMutator(float connection, float node, float conWeightShift, float conWeightRand, float conToggle)
    {
        MUTATE_CONNECTION_CHANCE = connection;
        MUTATE_NODE_CHANCE = node;
        MUTATE_CONNECTION_WEIGHT_SHIFT_CHANCE = conWeightShift;
        MUTATE_CONNECTION_WEIGHT_RANDOM_CHANCE = conWeightRand;
        MUTATE_CONNECTION_TOGGLE_CHANCE = conToggle;
    }

    public void Mutate(Genome genome)
    {
        if (Random.value < MUTATE_CONNECTION_CHANCE)
        {
            MutateConnection(genome);
        }
        if (Random.value < MUTATE_NODE_CHANCE)
        {
            MutateNode(genome);
        }
        if (Random.value < MUTATE_CONNECTION_WEIGHT_SHIFT_CHANCE)
        {
            MutateWeightShift(genome);
        }
        if (Random.value < MUTATE_CONNECTION_WEIGHT_RANDOM_CHANCE)
        {
            MutateWeightRandom(genome);
        }
        if (Random.value < MUTATE_CONNECTION_TOGGLE_CHANCE)
        {
            MutateToggleConnection(genome);
        }
    }

    private void MutateToggleConnection(Genome genome)
    {
        genome.ToggleRandomConnection();
    }

    private void MutateNode(Genome genome)
    {
        genome.MutateNode();
    }

    private void MutateConnection(Genome genome)
    {
        genome.MutateConnection();
    }

    private void MutateWeightRandom(Genome genome)
    {
        genome.MutateWeightRandom();
    }

    private void MutateWeightShift(Genome genome)
    {
        genome.MutateWeightShift();
    }
}

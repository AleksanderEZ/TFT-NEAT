using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ConnectionGene : IComparable<ConnectionGene>
{
    private NodeGene from;
    private NodeGene to;
    private float weight;
    private bool enabled = true;
    private static int INNOVATION_NUMBER = 0;
    private int innovation_number;

    public ConnectionGene(NodeGene from, NodeGene to)
    {
        innovation_number = INNOVATION_NUMBER;
        INNOVATION_NUMBER++;
        SetFrom(from);
        SetTo(to);
    }

    public ConnectionGene()
    {
        innovation_number = INNOVATION_NUMBER;
        INNOVATION_NUMBER++;
    }

    public NodeGene GetFrom() 
    { 
        return from;
    }

    public NodeGene GetTo()
    {
        return to;
    }

    public float GetWeight()
    {
        return weight;
    }

    public bool IsEnabled()
    {
        return enabled;
    }

    public void SetFrom(NodeGene from)
    {
        this.from = from;
    }

    public void SetTo(NodeGene to)
    {
        if (this.to != null)
        {
            this.to.RemoveIncomingConnection(this);
        }
        this.to = to;
        this.to.AddIncomingConnection(this);
    }

    public void SetEnabled(bool enabled)
    {
        this.enabled = enabled;
    }

    public void SetWeight(float weight)
    {
        this.weight = weight;
    }

    public bool Equals(ConnectionGene other)
    {
        if (!(other is ConnectionGene)) return false;
        if (GetFrom().GetX() == other.GetFrom().GetX() && GetFrom().GetY() == other.GetFrom().GetY() && GetTo().GetX() == other.GetTo().GetX() && GetTo().GetY() == other.GetTo().GetY()) return true;
        return false;
    }

    public int CompareTo(ConnectionGene other)
    {
        if (this == other) return 0;
        if (other == null) return -1;
        if (GetInnovationNumber() < other.GetInnovationNumber()) return -1;
        if (GetInnovationNumber() == other.GetInnovationNumber()) return 0;
        return 1;
    }

    public int GetInnovationNumber()
    {
        return innovation_number;
    }

    public void SetInnovationNumber(int innovationNumber)
    {
        innovation_number = innovationNumber;
    }

    public ConnectionGene Copy()
    {
        ConnectionGene copy = new ConnectionGene(from.Copy(), to.Copy());
        copy.SetInnovationNumber(innovation_number);
        copy.SetEnabled(enabled);
        copy.SetWeight(weight);
        return copy;
    }
}

using System;
using System.Collections;
using UnityEngine;

public class DonkeyKongController : MonoBehaviour
{
    [SerializeField] private Transform player;
    private Animator animator;
    [SerializeField] private BarrelController barrelController;
    private bool first = true;
    private bool thrown;

    private void Awake()
    {
        animator = GetComponent<Animator>();
    }

    void FixedUpdate()
    {
        if (animator.GetCurrentAnimatorStateInfo(0).IsName("Donkey_Kong_idle"))
        {
            ThrowBarrel();
        }
        if (thrown)
        {
            StartCoroutine(CheckThrowBarrelTiming());
            thrown = false;
        }
    }

    private IEnumerator CheckThrowBarrelTiming()
    {
        yield return new WaitWhile(() => !animator.GetCurrentAnimatorStateInfo(0).IsName("Donkey_Kong_throw"));
        if (first)
        {
            barrelController.ThrowBarrelDown();
        }
        else
        {
            barrelController.ThrowBarrelRight();
        }
        first = false;
    }

    private void ThrowBarrel()
    {
        animator.Play("Donkey_Kong_throwing");
        thrown = true;
    }
}

using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using Unity.VisualScripting;
using UnityEditor;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    private Rigidbody2D rb;
    private Vector2 direction;
    [SerializeField] private float speed;
    [SerializeField] private float jumpForce;
    [SerializeField] private Transform groundCheck;
    [SerializeField] private LayerMask whatIsGround;
    [SerializeField] private ContactFilter2D whatIsLadder;
    [SerializeField] private ContactFilter2D whatIsLadderTop;
    [SerializeField] private LayerMask whatIsBarrel;
    private bool facingRight = true;
    private Animator animator;
    private bool dying;
    private Collider2D[] results = new Collider2D[1];
    private bool canClimb;
    private bool climbing;
    private bool climbingAndMoving;
    private bool grounded;
    private bool won = false;
    private Vector3 lastPosition;
    private float timer = 0;
    private const int timeout = 3;

    // Controls
    private int up;
    private int down;
    private int left;
    private int right;
    private bool jump;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
    }

    private void Update()
    {
        SendDataToAnimator();
        if (climbing)
        {
            Climbing();
            return;
        }
        if ((up == 1 || down == 1) && canClimb)
        {
            climbing = true;
        }
        if (jump && grounded)
        {
            direction = Vector2.up * jumpForce;
        }
        else
        {
            direction += Physics2D.gravity * Time.deltaTime;
        }
        if (grounded)
        {
            direction.x = right - left;
            direction.y = Mathf.Max(direction.y, -1);
        }
        Flip();
    }

    private void FixedUpdate()
    {
        if (Time.frameCount % 5 == 0) lastPosition = rb.position;
        grounded = Physics2D.OverlapCircle(groundCheck.position, 0.2f, whatIsGround);
        if (animator.GetCurrentAnimatorStateInfo(0).IsName("Player_finished_climbing")) return;
        rb.MovePosition(rb.position + direction * speed * Time.deltaTime);
        results[0] = null;
        rb.OverlapCollider(whatIsLadder, results);
        if (results[0] != null)
        {
            canClimb = true;
        }
        else
        {
            canClimb = false;
        }
        if (Moved())
        {
            timer = 0;
        }
        else
        {
            timer += Time.deltaTime;
        }
        if (timer > timeout)
        {
            Deactivate();
        }
    }

    private bool Moved()
    {
        if (System.Math.Abs(rb.position.x - lastPosition.x) < Time.deltaTime * speed && System.Math.Abs(rb.position.y - lastPosition.y) < Time.deltaTime * speed)
        {
            return false;
        }
        return true;
    }

    public void Reset(Vector3 initialPosition)
    {
        transform.position = initialPosition;
        rb.simulated = true;
        GetComponent<SpriteRenderer>().color = Color.white;
        animator.enabled = true;
        enabled = true;
        timer = 0;
        lastPosition = initialPosition;
    }

    public void SetControls(float[] outputs)
    {
        int[] outputs_int = new int[outputs.Length];
        for (int i = 0; i < outputs_int.Length; i++)
        {
            outputs_int[i] = (int)Math.Round(outputs[i]);
        }
        SetUp(outputs_int[0]);
        SetLeft(outputs_int[1]);
        SetDown(outputs_int[2]);
        SetRight(outputs_int[3]);


        if (outputs_int[4] == 0)
        {
            SetJump(false);
        }
        else
        {
            SetJump(true);
        }
    }

    private void SetUp(int up)
    {
        this.up = up;
    }

    private void SetDown(int down)
    {
        this.down = down;
    }

    private void SetLeft(int left)
    {
        this.left = left;
    }

    private void SetRight(int right)
    {
        this.right = right;
    }

    private void SetJump(bool jump)
    {
        this.jump = jump;
    }

    private void Climbing()
    {
        direction.x = 0;
        direction.y = (up - down) * 0.5f;
        if (direction.y != 0)
        {
            climbingAndMoving = true;
        } else
        {
            climbingAndMoving = false;
        }
        if (isLadderTop())
        {
            direction.y = Mathf.Min(direction.y, 0f);
        }
        if (IsGroundedClimbing()) {
            climbing = false;
        }
    }

    private bool isLadderTop()
    {
        results[0] = null;
        rb.OverlapCollider(whatIsLadderTop, results);
        return results[0] != null;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.layer == LayerMask.NameToLayer("Barrel"))
        {
            //animator.Play("Player_dying");
            Deactivate();
        }

        if (collision.gameObject.layer == LayerMask.NameToLayer("Goal"))
        {
            Deactivate();
            won = true;
        }
    }

    public bool HasWon()
    {
        return won;
    }

    private void SendDataToAnimator()
    {
        animator.SetFloat("Speed", Mathf.Abs(direction.x));
        //animator.SetBool("Dying", dying);
        animator.SetBool("Climbing", climbing);
        animator.SetBool("ClimbingAndMoving", climbingAndMoving);
    }

    private void Flip()
    {
        if (direction.x > 0 && !facingRight || direction.x < 0 && facingRight)
        {
            facingRight = !facingRight;
            Vector3 localScale = transform.localScale;
            localScale.x *= -1f;
            transform.localScale = localScale;
        }
    }

    public bool IsGrounded()
    {
        return grounded;
    }

    public bool IsClimbing()
    {
        return climbing;
    }

    public bool CanClimb()
    {
        return canClimb;
    }

    private bool IsGroundedClimbing()
    {
        return Physics2D.Raycast(groundCheck.position, Vector2.down, 0.1f, whatIsGround);
    }

    private void Deactivate()
    {
        rb.simulated = false;
        GetComponent<SpriteRenderer>().color = Color.gray;
        animator.enabled = false;
        enabled = false;
        direction = Vector2.zero;
    }
}

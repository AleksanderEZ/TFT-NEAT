using System;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private int progress = 0;
    public enum Command { UP, LEFT, RIGHT, DOWN };
    private List<Command> commands;
    private bool finishedMoving = true;
    private float distance;
    private PlayerMovement playerMovement;
    private Vector3 initialPosition;

    private void Awake()
    {
        initialPosition = transform.localPosition;
        playerMovement = GetComponent<PlayerMovement>();
    }
    
    public void SetCommands(List<Command> commands)
    {
        this.commands = commands;
    }

    public List<Command> GetCommands()
    {
        return commands;
    }

    public void StartMoving()
    {
        finishedMoving = false;
    }

    public bool IsFinishedMoving()
    {
        return finishedMoving;
    }

    public float GetFitness()
    {
        float fitness = -distance + 13;
        fitness = Mathf.Clamp(fitness, 0, 13);
        return fitness;
    }

    public void Reset()
    {
        finishedMoving = true;
        distance = 0;
        progress = 0;
        playerMovement.Reset(initialPosition);
    }

    private void Update()
    {
        distance = Vector2.Distance(transform.localPosition, GeneticController.Instance.GetGoal().transform.localPosition);
        if (playerMovement.FinishedMoving() && !finishedMoving)
        {
            switch (commands[progress])
            {
                case Command.UP:
                    playerMovement.SetTarget(transform.localPosition + Vector3.up);
                    break;
                case Command.LEFT:
                    playerMovement.SetTarget(transform.localPosition + Vector3.left);
                    break;
                case Command.RIGHT:
                    playerMovement.SetTarget(transform.localPosition + Vector3.right);
                    break;
                case Command.DOWN:
                    playerMovement.SetTarget(transform.localPosition + Vector3.down);
                    break;
                default:
                    break;
            }
            progress++;
        }

        if (progress >= commands.Count || !playerMovement.enabled)
        {
            finishedMoving = true;
            playerMovement.Deactivate();
        } 
    }
}

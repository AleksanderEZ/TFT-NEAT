using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;

public class GeneticController : MonoBehaviour
{
    public static GeneticController Instance;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        } else
        {
            Destroy(this);
        }
        UnityEngine.Random.InitState(DateTime.Now.Millisecond);
    }

    [SerializeField]
    private GameObject playerPrefab;
    [SerializeField]
    private GameObject goal;
    private Queue<PlayerController> players = new Queue<PlayerController>();
    private Queue<PlayerController> nextGeneration = new Queue<PlayerController>();
    private bool running = false;
    private const int N_START_COMMANDS = 5;
    private const int POPULATION = 100;
    private const int LIMIT_GENERATIONS = 100;
    private const float CROSSOVER_CHANCE = 0.75f;
    private int GENERATION = 0;
    private float MAX_FITNESS = 0;

    [SerializeField]
    private GameObject generationsText;
    [SerializeField]
    private GameObject maxFitnessText;
    [SerializeField]
    private GameObject runningTextText;

    private void Start()
    {
        InitializePopulation();
    }

    private void Update()
    {
        if (GENERATION >= LIMIT_GENERATIONS)
        {
            Debug.LogWarning("Limit of generations has been reached");
            enabled = false;
            return;
        }
        if (running) return;
        running = true;
        UI();
        Run();
        StartCoroutine(Evolve());
    }

    private void UI()
    {
        TextMeshPro gens = generationsText.GetComponent<TextMeshPro>();
        TextMeshPro maxFitness = maxFitnessText.GetComponent<TextMeshPro>();
        TextMeshPro runningText = runningTextText.GetComponent<TextMeshPro>();

        gens.text = "Generation: " + GENERATION.ToString();
        maxFitness.text = "Max fitness: " + MAX_FITNESS.ToString("n2");
        runningText.text = "Running: " + running.ToString();
    }

    private void InitializePopulation()
    {
        GameObject player;
        PlayerController playerController;
        List<PlayerController.Command> commands;
        for (int i = 0; i < POPULATION; i++)
        {
            player = Instantiate(playerPrefab);
            playerController = player.GetComponent<PlayerController>();
            commands = GetRandomCommands(N_START_COMMANDS);
            playerController.SetCommands(commands);
            players.Enqueue(playerController);
        }
    }

    private List<PlayerController.Command> GetRandomCommands(int commandsCount)
    {
        List<PlayerController.Command> commands = new List<PlayerController.Command>();
        for (int i = 0;i < commandsCount;i++)
        {
            commands.Add(GetRandomCommand());
        }
        return commands;
    }

    private PlayerController.Command GetRandomCommand()
    {
        Array enumValues = Enum.GetValues(typeof(PlayerController.Command));
        int randomIndex = UnityEngine.Random.Range(0, enumValues.Length);
        PlayerController.Command randomCommand = (PlayerController.Command) enumValues.GetValue(randomIndex);
        return randomCommand;
    }

    private void Run()
    {
        foreach (PlayerController player in players)
        {
            player.StartMoving();
        }
    }

    private IEnumerator Evolve()
    {
        while (PlayersAlive())
        {
            yield return null;
        }

        BreedGeneration();

        Reset();

        GENERATION++;
        running = false;
    }



    private bool PlayersAlive()
    {
        foreach (PlayerController player in players)
        {
            if (!player.IsFinishedMoving())
            {
                return true;
            }
        }
        return false;
    }
    
    private void BreedGeneration()
    {
        nextGeneration.Clear();

        players = new Queue<PlayerController>(players.OrderByDescending(x => x.GetFitness()));
        nextGeneration.Enqueue(players.Peek());

        if (players.Peek().GetFitness() > MAX_FITNESS)
        {
            MAX_FITNESS = players.Peek().GetFitness();
        }

        players = new Queue<PlayerController>(players.OrderBy(x => x.GetFitness()));

        for(int i = 0; i < players.Count / 2 - 1; i++)
        {
            PlayerController player = players.Dequeue();
            Destroy(player.gameObject);
        }

        while (nextGeneration.Count < POPULATION)
        {
            Crossover();
        }

        RemoveLeftoverIndividuals();

        players = new Queue<PlayerController>(nextGeneration);
    }

    private void Crossover()
    {
        PlayerController parent1 = GetRandomPlayer();
        PlayerController parent2 = GetRandomPlayer();

        if (parent1 == parent2) return;
        if (parent1.GetCommands().Count != parent2.GetCommands().Count) return;
        if (parent1.GetFitness() < parent2.GetFitness())
        {
            PlayerController temp = parent1;
            parent1 = parent2;
            parent2 = temp;
        }

        int nsp = UnityEngine.Random.Range(0, parent1.GetCommands().Count);

        PlayerController child = Instantiate(playerPrefab).GetComponent<PlayerController>();
        List<PlayerController.Command> commands = new List<PlayerController.Command>();
        for (int i = 0; i < nsp; i++)
        {
            commands.Add(parent1.GetCommands()[i]);
        }

        for (int i = nsp; i < parent2.GetCommands().Count; i++)
        {
            commands.Add(parent2.GetCommands()[i]);
        }

        commands.Add(GetRandomCommand());
        commands.Add(GetRandomCommand());
        commands.Add(GetRandomCommand());
        commands.Add(GetRandomCommand());
        commands.Add(GetRandomCommand());

        child.SetCommands(commands);
        nextGeneration.Enqueue(child);
    }

    private PlayerController GetRandomPlayer()
    {
        int randomIndex = UnityEngine.Random.Range(0, players.Count);
        return players.ElementAt(randomIndex);
    }

    private void RemoveLeftoverIndividuals()
    {
        foreach (PlayerController player in players)
        {
            if (!nextGeneration.Contains(player))
            {
                Destroy(player.gameObject);
            }
        }
    }

    private void Reset()
    {
        foreach (PlayerController player in players)
        {
            player.Reset();
        }
    }

    public GameObject GetGoal()
    {
        return goal;
    }
}

using System;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    private Vector3 targetPosition;
    private Vector3 startPosition;
    [SerializeField]
    private float speed;
    private float progress = 0;

    private void Awake()
    {
        targetPosition = transform.position;
        progress = 1;
    }

    public void SetTarget(Vector3 targetPosition)
    {
        startPosition = transform.localPosition;
        this.targetPosition = targetPosition;
        if (progress > 0)
        {
            progress = 0.3f;
        }
    }

    public bool FinishedMoving()
    {
        return Mathf.Clamp01(progress) == 1;
    }

    void Update()
    {
        MoveToTarget();
        PaintTarget();
        PointAtTarget();
    }

    private void PointAtTarget()
    {
        Vector3 current = transform.position;
        var direction = targetPosition - current;
        var angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.AngleAxis(angle - 90, Vector3.forward);
    }

    private void PaintTarget()
    {
        Debug.DrawLine(transform.localPosition, targetPosition, Color.red);
        Debug.DrawLine(startPosition, transform.localPosition, Color.blue);
    }

    private void MoveToTarget()
    {
        if (!FinishedMoving())
        {
            Vector2 newPosition = Vector2.Lerp(transform.localPosition, targetPosition, progress * Time.deltaTime);
            transform.localPosition = new Vector3(newPosition.x, newPosition.y, transform.localPosition.z);
            progress += speed;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (IsWall(collision))
        {
            Deactivate();
        }   
    }

    private bool IsWall(Collider2D collision)
    {
        if (collision.gameObject.layer == 3)
        {
            return true;
        }
        return false;
    }

    public void Deactivate()
    {
        enabled = false;
        GetComponent<SpriteRenderer>().color = Color.gray;
    }

    public void Reset(Vector3 initialPosition)
    {
        transform.localPosition = initialPosition;
        transform.rotation = Quaternion.identity;
        targetPosition = initialPosition;
        enabled = true;
        GetComponent<SpriteRenderer>().color = Color.white;
    }
}

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Genome
{
    private HashSet<NodeGene> nodes = new HashSet<NodeGene>();
    private HashSet<ConnectionGene> connections = new HashSet<ConnectionGene>();
    private float fitness = 0;
    private int globalRank;
    private Species species;
    private string playerId;

    public void SetSpecies(Species species)
    {
        this.species = species; 
    }

    public static Genome Crossover(Genome g1, Genome g2)
    {
        if (g2.GetFitness() > g1.GetFitness())
        {
            Genome temp = g1;
            g1 = g2;
            g2 = temp;
        }

        Genome child = new Genome();

        int indexG1 = 0;
        int indexG2 = 0;

        ConnectionGene[] connections1 = g1.GetConnections().ToArray();
        ConnectionGene[] connections2 = g2.GetConnections().ToArray();

        while (indexG1 < connections1.Length && indexG2 < connections2.Length)
        {
            ConnectionGene connectionGene1 = connections1[indexG1];
            ConnectionGene connectionGene2 = connections1[indexG1];
            int innovationNumber1 = connections1[indexG1].GetInnovationNumber();
            int innovationNumber2 = connections2[indexG2].GetInnovationNumber();
            if (innovationNumber1 == innovationNumber2)
            {
                if (UnityEngine.Random.Range(0, 1) < 0.5)
                {
                    ConnectionGene newConnection = new ConnectionGene(connectionGene1.GetFrom(), connectionGene1.GetTo());
                    newConnection.SetWeight(connectionGene1.GetWeight());
                    newConnection.SetEnabled(connectionGene1.IsEnabled());
                    child.AddConnection(newConnection);
                }
                else
                {
                    ConnectionGene newConnection = new ConnectionGene(connectionGene2.GetFrom(), connectionGene2.GetTo());
                    newConnection.SetWeight(connectionGene2.GetWeight());
                    newConnection.SetEnabled(connectionGene2.IsEnabled());
                    child.AddConnection(newConnection);
                }
                indexG1++;
                indexG2++;
            }
            else if (innovationNumber1 > innovationNumber2)
            {
                indexG2++;
            }
            else
            {
                ConnectionGene newConnection = new ConnectionGene(connectionGene1.GetFrom(), connectionGene1.GetTo());
                newConnection.SetWeight(connectionGene1.GetWeight());
                newConnection.SetEnabled(connectionGene1.IsEnabled());
                child.AddConnection(newConnection);
                indexG1++;
            }
        }

        while (indexG1 < connections1.Length)
        {
            ConnectionGene connectionGene1 = connections1[indexG1];
            int innovationNumber1 = connections1[indexG1].GetInnovationNumber();
            child.AddConnection(connectionGene1);
            indexG1++;
        }

        foreach (ConnectionGene gene in child.GetConnections())
        {
            child.AddNode(gene.GetFrom());
            child.AddNode(gene.GetTo());
        }

        return child;
    }

    public HashSet<NodeGene> GetNodes() 
    {
        return nodes; 
    }
    public HashSet<ConnectionGene> GetConnections() 
    { 
        return connections; 
    }

    public float GetFitness()
    {
        return fitness;
    }

    public void SetFitness(float fitness)
    {
        this.fitness = fitness;
    }

    public void AddNode(NodeGene nodeGene)
    {
        nodes.Add(nodeGene);
        nodes.OrderBy(x => x.GetInnovationNumber());
    }

    public void AddConnection(ConnectionGene connectionGene)
    { 
        connections.Add(connectionGene);
        connections.OrderBy(x => x.GetInnovationNumber());
    }

    public void ToggleRandomConnection()
    {
        ConnectionGene[] connectionsArray = connections.ToArray();
        if (connectionsArray.Length == 0) return;
        ConnectionGene connection = connectionsArray[UnityEngine.Random.Range(0, connectionsArray.Length)];
        connection.SetEnabled(!connection.IsEnabled());
    }

    public void MutateNode()
    {
        ConnectionGene[] connectionsArray = connections.ToArray();
        if (connectionsArray.Length == 0) return;
        ConnectionGene connection = connectionsArray[UnityEngine.Random.Range(0, connectionsArray.Length)];
        if (connection == null) return;

        NodeGene from = connection.GetFrom();
        NodeGene to = connection.GetTo();

        NodeGene middle = new NodeGene();
        middle.SetX((from.GetX() + to.GetX()) / 2);
        middle.SetY((from.GetY() + to.GetY()) / 2);

        ConnectionGene connection1 = new ConnectionGene(from, middle);

        ConnectionGene connection2 = new ConnectionGene(middle, to);

        connection1.SetWeight(1);
        connection2.SetWeight(connection.GetWeight());
        connection2.SetEnabled(connection.IsEnabled());
        connections.Remove(connection);

        nodes.Add(middle);
        connections.Add(connection1);
        connections.Add(connection2);
    }

    public void MutateWeightRandom()
    {
        ConnectionGene[] connectionsArray = connections.ToArray();
        if (connectionsArray.Length == 0) return;
        ConnectionGene connection = connectionsArray[UnityEngine.Random.Range(0, connectionsArray.Length)];
        connection.SetWeight(UnityEngine.Random.Range(-2f, 2f));
    }

    public void MutateConnection()
    {
        NodeGene[] nodesArray = nodes.ToArray();
        if (nodesArray.Length <= 0) return;

        for (int i = 0; i < 50; i++)
        {
            NodeGene node1 = nodesArray[UnityEngine.Random.Range(0, nodesArray.Length)];
            NodeGene node2 = nodesArray[UnityEngine.Random.Range(0, nodesArray.Length)];

            if (node1.GetInnovationNumber() == node2.GetInnovationNumber()) continue;
            if (node1.GetX() == node2.GetX()) continue;

            ConnectionGene newConnection;

            if (node1.GetX() < node2.GetX())
            {
                newConnection = new ConnectionGene(node1, node2);
            }
            else
            {
                newConnection = new ConnectionGene(node2, node1);
            }

            if (ConnectionExists(newConnection)) continue;

            newConnection.SetWeight(UnityEngine.Random.Range(-2, 2));
            connections.Add(newConnection);
            break;
        }
    }

    private bool ConnectionExists(ConnectionGene connection)
    {
        foreach (ConnectionGene currentConnection in connections)
        {
            if (connection.Equals(currentConnection))
            {
                return true;
            }
        }
        return false;
    }

    public void MutateWeightShift()
    {
        ConnectionGene[] connectionsArray = connections.ToArray();
        if (connectionsArray.Length == 0) return;
        ConnectionGene connection = connectionsArray[UnityEngine.Random.Range(0, connectionsArray.Length)];
        connection.SetWeight(connection.GetWeight() * UnityEngine.Random.Range(0.75f, 1.251f));
    }

    public Genome Copy()
    {
        Genome copy = new Genome();
        copy.SetFitness(0);

        foreach (ConnectionGene connection in connections)
        {
            copy.AddConnection(connection.Copy());
            copy.AddNode(connection.GetFrom());
            copy.AddNode(connection.GetTo());
        }

        return copy;
    }

    public float[] EvaluateNetwork(float[] inputs)
    {
        List<NodeGene> input_nodes = new List<NodeGene>();
        List<NodeGene> hidden_nodes = new List<NodeGene>();
        List<NodeGene> output_nodes = new List<NodeGene>();

        foreach (NodeGene node in nodes)
        {
            if (node.GetX() <= NEAT.Instance.GetInputX())
            {
                input_nodes.Add(node);
            } else if (node.GetX() >= NEAT.Instance.GetOutputX()) {
                output_nodes.Add(node);
            } else
            {
                hidden_nodes.Add(node);
            }
        }


        if (inputs.Length != input_nodes.Count) return null;

        float[] outputs = new float[NEAT.Instance.GetOutputs()];

        if (outputs.Length != output_nodes.Count) return null;

        Debug.Log("Evaluating inputs: " + input_nodes.Count);
        int i = 0;
        foreach (NodeGene node in input_nodes)
        {
            node.SetOutput(inputs[i]);
            i++;
        }
        Debug.Log("Evaluating hidden: " + hidden_nodes.Count);

        hidden_nodes.OrderBy(x => x.GetX());
        foreach (NodeGene node in hidden_nodes)
        {
            node.CalculateOutput();
        }
        Debug.Log("Evaluating outputs: " + output_nodes.Count);

        i = 0;
        foreach (NodeGene node in output_nodes)
        {
            node.CalculateOutput();
            outputs[i] = node.GetOutput();
            i++;
        }
        return outputs;
    }

    public string GetPlayerId()
    {
        return playerId;
    }

    public void SetPlayerId(string playerId)
    {
        this.playerId = playerId;
    }

    public void SetRanking(int rank)
    {
        this.globalRank = rank;
    }

    public void AskPlayerFitness()
    {
        fitness =  NEAT.Instance.FindPlayerById(playerId).GetFitness();
    }

    public void Print()
    {
        Debug.Log("Genome rank: " + globalRank + "fitness: " + fitness + ", n_conn: " + connections.Count + ", n_nodes: " + nodes.Count);
    }
}

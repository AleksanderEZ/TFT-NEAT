using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ConnectionGene : Gene
{
    private NodeGene from;
    private NodeGene to;
    private float weight;
    private bool enabled = true;

    public ConnectionGene(NodeGene from, NodeGene to) : base()
    {
        SetFrom(from);
        SetTo(to);
    }

    public ConnectionGene() : base()
    {
    }

    public NodeGene GetFrom() 
    { 
        return from;
    }

    public NodeGene GetTo()
    {
        return to;
    }

    public float GetWeight()
    {
        return weight;
    }

    public bool IsEnabled()
    {
        return enabled;
    }

    public void SetFrom(NodeGene from)
    {
        this.from = from;
    }

    public void SetTo(NodeGene to)
    {
        if (this.to != null)
        {
            this.to.RemoveIncomingConnection(this);
        }
        this.to = to;
        this.to.AddIncomingConnection(this);
    }

    public void SetEnabled(bool enabled)
    {
        this.enabled = enabled;
    }

    public void SetWeight(float weight)
    {
        this.weight = weight;
    }

    public ConnectionGene Copy()
    {
        ConnectionGene connectionGene = new ConnectionGene();
        connectionGene.SetWeight(weight);
        connectionGene.SetEnabled(enabled);
        connectionGene.SetInnovationNumber(innovationNumber);
        connectionGene.SetFrom(from.Copy());
        connectionGene.SetTo(to.Copy());
        return connectionGene;
    }

    public bool Equals(ConnectionGene other)
    {
        if (!(other is ConnectionGene)) return false;
        if (GetFrom().GetX() == other.GetFrom().GetX() && GetFrom().GetY() == other.GetFrom().GetY() && GetTo().GetX() == other.GetTo().GetX() && GetTo().GetY() == other.GetTo().GetY()) return true;
        return false;
    }
}

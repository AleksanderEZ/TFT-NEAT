using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NodeGene : Gene
{
    private float x, y;
    private float output;
    private List<ConnectionGene> incomingConnections = new List<ConnectionGene>();

    public NodeGene() : base()
    {

    }

    public float GetX() { return x; }
    public float GetY() { return y; }
    public void SetX(float x) { this.x = x; }
    public void SetY(float y) { this.y = y; }

    public float GetOutput()
    {
        return output;
    }

    internal void SetOutput(float output)
    {
        this.output = output;
    }
    public void AddIncomingConnection(ConnectionGene connection) 
    {
        incomingConnections.Add(connection);
    }

    public void RemoveIncomingConnection(ConnectionGene connection)
    {
        incomingConnections.Remove(connection);
    }

    public void CalculateOutput()
    {
        if (incomingConnections == null && x != 0) { output = 0; return; }
        float sum = 0;
        foreach (ConnectionGene connectionGene in incomingConnections)
        {
            if (connectionGene.IsEnabled())
            {
                sum += connectionGene.GetWeight() * connectionGene.GetFrom().GetOutput();
            }
        }
        output = ActivationFunctions.Sigmoid(sum);
    }

    public NodeGene Copy() { 
        NodeGene node = new NodeGene();
        node.SetX(x);
        node.SetY(y);
        return node;
    }
}

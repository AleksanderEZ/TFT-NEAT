using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;

public class NEATPainter : MonoBehaviour
{
    private ArrayList nodes = new ArrayList();
    private ArrayList connections = new ArrayList();
    private ArrayList weights = new ArrayList();
    public static NEATPainter Instance = null;

    public void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(this);
        }
        else
        {
            Instance = this;
        }
    }

    public void PaintGenome(Genome genome)
    {
        Clear();

        foreach (NodeGene node in genome.GetNodes())
        {
            Vector2 center = new Vector2(node.GetX(), node.GetY());
            AddNeuron(center, node.GetOutput());
        }
        
        foreach (ConnectionGene connection in genome.GetConnections())
        {
            NodeGene fromNode = connection.GetFrom();
            Vector2 from = new Vector2(fromNode.GetX(), fromNode.GetY());

            NodeGene toNode = connection.GetTo();
            Vector2 to = new Vector2(toNode.GetX(), toNode.GetY());

            AddConnection(from, to, connection.GetWeight(), connection.IsEnabled(), connection.GetInnovationNumber());
        }
    }

    private bool AddNeuron(Vector2 center, float output)
    {
        Transform sphere;
        sphere = GameObject.CreatePrimitive(PrimitiveType.Sphere).transform;
        sphere.name = "Neuron";
        MeshRenderer meshRenderer = sphere.GetComponent<MeshRenderer>();
        meshRenderer.material = new Material(Shader.Find("Unlit/Color"));
        meshRenderer.sharedMaterial.color = Color.white;
        sphere.position = center;
        sphere.localScale = Vector3.one;
        nodes.Add(sphere);

        GameObject textObject = new GameObject("TextMeshPro");
        textObject.transform.localPosition = new Vector3(center.x, center.y, -1);
        textObject.transform.SetParent(sphere);
        TextMeshPro textMesh = textObject.AddComponent<TextMeshPro>();
        textMesh.text = output.ToString();
        textMesh.fontSize = 7.5f;
        textMesh.alignment = TextAlignmentOptions.Center;
        textMesh.alignment = TextAlignmentOptions.Midline;
        textMesh.color = Color.red;
        weights.Add(textObject);

        return true;
    }

    private bool AddConnection(Vector2 from, Vector2 to, float weight, bool isEnabled, int innovationNumber)
    {
        Transform line = new GameObject().transform;
        line.name = "Connection";
        LineRenderer lineRenderer = line.AddComponent<LineRenderer>();
        lineRenderer.material = new Material(Shader.Find("Sprites/Default"));
        lineRenderer.startColor = Color.white;
        lineRenderer.endColor = Color.white;
        if(!isEnabled)
        {
            lineRenderer.startColor = Color.gray;
            lineRenderer.endColor = Color.gray;
        }
        lineRenderer.startWidth = 0.2f;
        lineRenderer.endWidth = 0.2f;
        lineRenderer.positionCount = 2;
        lineRenderer.SetPosition(0, from);
        lineRenderer.SetPosition(1, to);
        connections.Add(line);

        GameObject textObject = new GameObject("TextMeshPro");
        textObject.transform.SetParent(line);
        textObject.transform.localPosition = (from + to) /2 + new Vector2(0, 0.5f);
        TextMeshPro textMesh = textObject.AddComponent<TextMeshPro>();
        textMesh.text = weight.ToString() + " / " + innovationNumber.ToString();
        textMesh.fontSize = 7.5f;
        textMesh.alignment = TextAlignmentOptions.Center;
        textMesh.alignment = TextAlignmentOptions.Baseline;
        weights.Add(textObject);

        return true;
    }

    public void Clear()
    {
        foreach (Transform node in nodes) 
        {
            Destroy(node.gameObject);
        }
        nodes.Clear();

        foreach (Transform connection in connections)
        {
            Destroy(connection.gameObject);
        }
        connections.Clear();

        foreach (GameObject weight in weights)
        {
            Destroy(weight.gameObject);
        }
        connections.Clear();
    }
}

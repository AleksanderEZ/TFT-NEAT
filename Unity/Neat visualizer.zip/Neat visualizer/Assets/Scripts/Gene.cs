using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gene
{
    protected int innovationNumber;

    public Gene()
    {
        SetInnovationNumber(NEAT.Instance.NewInnovation());
    }

    public int GetInnovationNumber()
    {
        return innovationNumber;
    }

    public void SetInnovationNumber(int innovationNumber)
    {
        this.innovationNumber = innovationNumber;
    }
}

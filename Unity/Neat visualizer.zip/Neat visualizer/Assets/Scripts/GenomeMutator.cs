using UnityEngine;

public class GenomeMutator
{
    private float MUTATE_CONNECTION_CHANCE;
    private float MUTATE_NODE_CHANCE;
    private float MUTATE_CONNECTION_WEIGHT_SHIFT_CHANCE;
    private float MUTATE_CONNECTION_WEIGHT_RANDOM_CHANCE;
    private float MUTATE_CONNECTION_TOGGLE_CHANCE;

    public GenomeMutator(float connection, float node, float conWeightShift, float conWeightRand, float conToggle)
    {
        MUTATE_CONNECTION_CHANCE = connection;
        MUTATE_NODE_CHANCE = node;
        MUTATE_CONNECTION_WEIGHT_SHIFT_CHANCE = conWeightShift;
        MUTATE_CONNECTION_WEIGHT_RANDOM_CHANCE = conWeightRand;
        MUTATE_CONNECTION_TOGGLE_CHANCE = conToggle;
    }

    public void Mutate(Genome genome)
    {
        if (Random.value < MUTATE_CONNECTION_CHANCE)
        {
            Debug.Log("Mutating connection");
            MutateConnection(genome);
            Debug.Log("Connections: " + genome.GetConnections().Count); 
        }
        if (Random.value < MUTATE_NODE_CHANCE)
        {
            Debug.Log("Mutating node");
            MutateNode(genome);
        }
        if (Random.value < MUTATE_CONNECTION_WEIGHT_SHIFT_CHANCE)
        {
            Debug.Log("Mutating connection weight shift");
            MutateWeightShift(genome);
        }
        if (Random.value < MUTATE_CONNECTION_WEIGHT_RANDOM_CHANCE)
        {
            Debug.Log("Mutating connection weight random");
            MutateWeightRandom(genome);
        }
        if (Random.value < MUTATE_CONNECTION_TOGGLE_CHANCE)
        {
            Debug.Log("Mutating connection toggle");
            MutateToggleConnection(genome);
        }
    }

    public void MutateToggleConnection(Genome genome)
    {
        genome.ToggleRandomConnection();
    }

    public void MutateNode(Genome genome)
    {
        genome.MutateNode();
    }

    public void MutateConnection(Genome genome)
    {
        genome.MutateConnection();
    }

    public void MutateWeightRandom(Genome genome)
    {
        genome.MutateWeightRandom();
    }

    public void MutateWeightShift(Genome genome)
    {
        genome.MutateWeightShift();
    }
}

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.Mathematics;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SocialPlatforms;

public class Species
{
    private List<Genome> genomes = new List<Genome>();
    private float averageFitness = 0;
    private float topFitness = 0;
    private int staleness = 0;
    private List<Genome> childBuffer = new List<Genome>();

    public bool Add(Genome genome)
    {
        if (Distance(genome) > NEAT.Instance.GetDistanceThreshold()) return false;
        genomes.Add(genome);
        genome.SetSpecies(this);
        return true;
    }

    private float Distance(Genome g2)
    {
        int indexG1 = 0;
        int indexG2 = 0;

        Genome g1 = GetRepresentative();

        ConnectionGene[] connectionGenes1 = g1.GetConnections().ToArray();
        ConnectionGene[] connectionGenes2 = g2.GetConnections().ToArray();

        List<int> innovationList1 = new List<int>();
        List<int> innovationList2 = new List<int>();

        for (int i = 0; i < connectionGenes1.Length; i++)
        {
            innovationList1.Add(connectionGenes1[i].GetInnovationNumber());
        }

        for (int i = 0; i < connectionGenes2.Length; i++)
        {
            innovationList2.Add(connectionGenes2[i].GetInnovationNumber());
        }

        int[] innovations1 = innovationList1.ToArray();
        int[] innovations2 = innovationList2.ToArray();

        int highestInnovation1 = 0;
        if (innovations1.Length > 0)
        {
            highestInnovation1 = innovations1.Max();
        }

        int highestInnovation2 = 0;
        if (innovations2.Length > 0)
        {
            highestInnovation2 = innovations2.Max();
        }

        if (highestInnovation2 > highestInnovation1)
        {
            Genome temp = g1;
            g1 = g2;
            g2 = temp;
        }

        ConnectionGene[] connections1 = g1.GetConnections().ToArray();
        ConnectionGene[] connections2 = g2.GetConnections().ToArray();

        float weightDifference = 0;
        int disjointGenes = 0;
        int sameGene = 0;

        while (indexG1 < connections1.Length && indexG2 < connections2.Length)
        {
            ConnectionGene connectionGene1 = connections1[indexG1];
            ConnectionGene connectionGene2 = connections1[indexG1];
            int innovationNumber1 = connections1[indexG1].GetInnovationNumber();
            int innovationNumber2 = connections2[indexG2].GetInnovationNumber();
            if (innovationNumber1 == innovationNumber2)
            {
                weightDifference += Math.Abs(connectionGene1.GetWeight() - connectionGene2.GetWeight());
                sameGene++;
                indexG1++;
                indexG2++;
            }
            else if (innovationNumber1 > innovationNumber2)
            {
                disjointGenes++;
                indexG2++;
            }
            else
            {
                disjointGenes++;
                indexG1++;
            }
        }

        weightDifference /= sameGene;
        int excessGenes = connections1.Length - indexG1;
        float numberOfConnections = Math.Max(connections1.Length, connections2.Length);
        if (numberOfConnections < 20) numberOfConnections = 1;

        return NEAT.Instance.GetDeltaDisjoint() * disjointGenes / numberOfConnections + excessGenes / numberOfConnections + weightDifference * NEAT.Instance.GetDeltaWeights();
    }

    private Genome GetRepresentative()
    {
        return genomes[UnityEngine.Random.Range(0, genomes.Count)];
    }

    public void Remove(Genome genome) 
    { 
        genomes.Remove(genome);
    }   

    public void Clear()
    {
        genomes.Clear();
    }

    public int Size()
    {
        return genomes.Count;
    }

    public void CalculateAverageFitness()
    {
        float sum = 0;
        foreach (Genome genome in genomes)
        {
            sum += genome.GetFitness();
        }
        averageFitness = sum / genomes.Count;
    }

    public void Cull(int elitism)
    {
        genomes.OrderBy(x => x.GetFitness());
        int remaining = (int) Mathf.Ceil(genomes.Count / 2);
        if (elitism > 0)
        {
            remaining = elitism; 
        }
        genomes.RemoveRange(remaining - 1, genomes.Count - 1);
    }

    public void BreedChild()
    {
        Genome child;
        if (UnityEngine.Random.value < NEAT.Instance.GetCrossoverChance())
        {
            Genome g1 = GetRandomGenome();
            Genome g2 = GetRandomGenome();
            child = Genome.Crossover(g1, g2);
        } else
        {
            child = GetRandomGenome().Copy();
        }
        NEAT.Instance.GetMutator().Mutate(child);
        genomes.Add(child);
    }

    private Genome GetRandomGenome()
    {
        Genome[] selectedGenomes = (Genome[]) genomes.ToArray();
        Genome genome = selectedGenomes[UnityEngine.Random.Range(0, selectedGenomes.Length)];
        return genome;
    }

    public void EvaluateFitness()
    {
        foreach (Genome genome in genomes)
        {
            genome.AskPlayerFitness();
        }
    }

    public Genome FindGenomeByPlayerId(string playerId)
    {
        foreach (Genome genome in genomes)
        {
            if (genome.GetPlayerId().Equals(playerId))
            {
                return genome;
            }
        }
        return null;
    }

    public void FlushChildren()
    {
        while (genomes.Count < NEAT.Instance.GetPopulation())
        {
            Genome child = childBuffer.First();
            childBuffer.Remove(child);
            genomes.Add(child);
        }
        childBuffer.Clear();
    }

    public void BreedChildren(float TOTAL_AVERAGE_FITNESS)
    {
        for (int i = 0; i < NEAT.Instance.GetPopulation(); i++)
        {
            Genome child;
            if (UnityEngine.Random.value < NEAT.Instance.GetCrossoverChance())
            {
                Genome g1 = GetRandomGenome();
                Genome g2 = GetRandomGenome();
                child = Genome.Crossover(g1, g2);
            }
            else
            {
                child = GetRandomGenome().Copy();
            }
            NEAT.Instance.GetMutator().Mutate(child);
            childBuffer.Add(child);
        }
    }

    private class ByFitness : IComparer<Genome>
    {
        public int Compare(Genome x, Genome y)
        {
            if (x.GetFitness() == y.GetFitness()) return 0;
            if (x.GetFitness() < y.GetFitness()) return -1;
            return 1;
        }
    }

    public List<Genome> GetGenomes()
    {
        return genomes;
    }

    public void Print()
    {
        Debug.Log("---Species---");
        foreach (Genome genome in genomes)
        {
            genome.Print();
        }
    }

    public float GetAverageFitness()
    {
        return averageFitness;
    }

    public void EvaluateStaleness()
    {
        genomes.OrderBy(x => x.GetFitness());
        float bestFitness = genomes.First().GetFitness();

        if (bestFitness > topFitness) {
            topFitness = bestFitness;
            staleness = 0;
        }
        else {
            staleness = staleness + 1;
        }
    }

    public int GetStaleness()
    {
        return staleness;
    }

    public float GetTopFitness()
    {
        return topFitness;
    }
}

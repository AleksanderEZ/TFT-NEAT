using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.UIElements;
using static UnityEditor.Experimental.AssetDatabaseExperimental.AssetDatabaseCounters;

public class NEAT : MonoBehaviour
{
    private const string FILE_NAME = "_DKNEAT.backup";

    public static NEAT Instance;
    private ArrayList speciesArray = new ArrayList();
    private const int POPULATION = 100;
    private const int INPUTS = 5;
    private const int OUTPUS = 3;
    private const int INPUTS_X = 0;
    private const int OUTPUTS_X = 30;

    private const float DISTANCE_THRESHOLD = 1f;
    private const float DELTA_WEIGHTS = 0.4f;
    private const float DELTA_DISJOINT = 2f;
    private const int STOP_CONDITION = 5;
    private const int TIMEOUT = 5;
    private const int ELITISM = 1;
    private const float CROSSOVER_CHANCE = 0.75f;
    private const float MUTATE_CONNECTION_CHANCE = 0.5f;
    private const float MUTATE_NODE_CHANCE = 0.2f;
    private const float MUTATE_CONNECTION_WEIGHT_SHIFT_CHANCE = 0.2f;
    private const float MUTATE_CONNECTION_WEIGHT_RANDOM_CHANCE = 0.3f;
    private const float MUTATE_CONNECTION_TOGGLE_CHANCE = 0.2f;
    public const int CAMERA_HEIGHT = 18;
    private NEATPainter painter;
    private GenomeMutator genomeMutator;

    private int GENERATION = 0;
    private int INNOVATION_NUMBER = 0;
    private int MAX_FITNESS = 0;
    private float TOTAL_AVERAGE_FITNESS = 0;
    private int STALENESS_THRESHOLD;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(this);
        }
        else
        {
            Instance = this;
        }
        genomeMutator = new GenomeMutator(MUTATE_CONNECTION_CHANCE, MUTATE_NODE_CHANCE, MUTATE_CONNECTION_WEIGHT_SHIFT_CHANCE, MUTATE_CONNECTION_WEIGHT_RANDOM_CHANCE, MUTATE_CONNECTION_TOGGLE_CHANCE);
        painter = NEATPainter.Instance;
        UnityEngine.Random.InitState((int)DateTime.Now.Ticks);
    }

    private void Start()
    {
        Genome test = NewGenome();
        for (int i = 0; i < 10; i++)
        {
            genomeMutator.Mutate(test);
        }
        test.EvaluateNetwork(new float[] {0, 0.5f, 1f, 0.75f, 0});
        painter.PaintGenome(test);
    }

    private void InitializePopulation()
    {
        for (int i = 0; i < POPULATION; i++)
        {
            Genome genome = NewGenome();
            AddToSpecies(genome);
        }
    }

    private Genome NewGenome()
    {
        Genome genome = new Genome();
        for (int i = 0; i < INPUTS; i++)
        {
            NodeGene node = new NodeGene();
            node.SetX(INPUTS_X);
            node.SetY(i * 2);
            genome.AddNode(node);
        }
        for (int i = 0; i < OUTPUS; i++)
        {
            NodeGene node = new NodeGene();
            node.SetX(OUTPUTS_X);
            node.SetY(i * 2);
            genome.AddNode(node);
        }
        return genome;
    }

    private void AddToSpecies(Genome genome)
    {
        bool found = false;
        foreach (Species species in speciesArray)
        {
            if (species.Add(genome))
            {
                found = true;
                break;
            }
        }
        if (!found)
        {
            Species newSpecies = new Species();
            newSpecies.Add(genome);
        }
    }

    private void CalculateFitness()
    {
        foreach (Species species in speciesArray)
        {
            species.EvaluateFitness();
        }
    }

    private void Evolve()
    {
        foreach (Species species in speciesArray)
        {
            species.Cull(0);
        }

        RankGenomes();

        RemoveStaleSpecies();

        RankGenomes();

        foreach (Species species in speciesArray)
        {
            species.CalculateAverageFitness();
        }

        RemoveWeakSpecies();

        CalculateTotalAverageFitness();

        foreach (Species species in speciesArray)
        {
            species.BreedChildren(TOTAL_AVERAGE_FITNESS);
        }

        foreach (Species species in speciesArray)
        {
            species.Cull(ELITISM);
        }

        foreach (Species species in speciesArray)
        {
            species.FlushChildren();
        }

        GENERATION++;
        SaveGenerationToText();
    }

    private void RankGenomes()
    {
        List<Genome> genomes = new List<Genome>();
        foreach (Species species in speciesArray)
        {
            genomes.AddRange(species.GetGenomes());
        }
        genomes.OrderBy(x => x.GetFitness());

        Genome[] genomesArr = genomes.ToArray();
        for (int i = 1; i <= genomes.Count; i++)
        {
            genomesArr[i].SetRanking(i);
        }
    }

    private void RemoveStaleSpecies()
    {
        foreach (Species species in speciesArray)
        {
            species.EvaluateStaleness();
            if(species.GetStaleness() >= STALENESS_THRESHOLD && species.GetTopFitness() < MAX_FITNESS)
            {
                speciesArray.Remove(species);
            }
        }
    }

    private void RemoveWeakSpecies()
    {
        CalculateTotalAverageFitness();
        foreach (Species species in speciesArray)
        {
            float speciesAverageSituation = Mathf.Floor(species.GetAverageFitness() / TOTAL_AVERAGE_FITNESS * POPULATION);
            if (speciesAverageSituation < 1f)
            {
                speciesArray.Remove(species);
            }
        }
    }

    private void CalculateTotalAverageFitness()
    {
        TOTAL_AVERAGE_FITNESS = 0;
        foreach (Species species in speciesArray)
        {
            TOTAL_AVERAGE_FITNESS += species.GetAverageFitness();
        }
    }

    private void SaveGenerationToText()
    {
        string fileName = GENERATION.ToString() + FILE_NAME;
        string text = GENERATION.ToString() + "\n";
        //fill text
        File.WriteAllText(fileName, text);
    }

    private void PrintSpecies()
    {
        foreach (Species species in speciesArray)
        {
            species.Print();
        }
    }

    private void InitializeRun()
    {
        throw new NotImplementedException();
    }

    public float GetCrossoverChance()
    {
        return CROSSOVER_CHANCE;
    }

    public int NewInnovation()
    {
        return INNOVATION_NUMBER++;
    }

    public GenomeMutator GetMutator()
    {
        return genomeMutator;
    }

    internal float GetInputX()
    {
        return INPUTS_X;
    }

    internal float GetOutputX()
    {
        return OUTPUTS_X;
    }

    internal int GetOutputs()
    {
        return OUTPUS;
    }

    internal int GetInputs()
    {
        return INPUTS;
    }

    internal float GetDistanceThreshold()
    {
        return DISTANCE_THRESHOLD;
    }

    public Genome FindGenomeByPlayerId(string playerId)
    {
        Genome genome = null;
        foreach (Species species in speciesArray)
        {
            genome = species.FindGenomeByPlayerId(playerId);
        }
        return genome;
    }

    public Genome FindPlayerById(string playerId)
    {
        return null;
    }

    internal float GetDeltaDisjoint()
    {
        return DELTA_DISJOINT;
    }

    internal float GetDeltaWeights()
    {
        return DELTA_WEIGHTS;
    }

    public int GetPopulation()
    {
        return POPULATION;
    }
}
